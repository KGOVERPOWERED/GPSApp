package com.example.gpsapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements LocationListener{
    double currentLat;
    double currentLong;
    double prevlat;
    double prevLong;
    double totalDistance=0;
    double time = SystemClock.elapsedRealtime();
    TextView t;
    TextView t2;
    TextView t3;
    TextView t4;
    LocationManager l;
    LocationListener locationListener;
    Geocoder geocoder;
    List<Address> address;
    ArrayList<Location> addressList = new ArrayList<>();
    ArrayList<Location> location1 = new ArrayList<>();
    Location currentLocation;




    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @SuppressLint("MissingPermission")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        t = findViewById(R.id.text);
        t2 = findViewById(R.id.textView);
        t3 = findViewById(R.id.textView2);
        t4 = findViewById(R.id.textView4);
        l = (LocationManager) getSystemService(LOCATION_SERVICE);




        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 0);
            return;
        } else
            l.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1, this);


        /* Runnable r= ()->{
           System.out.println("hi");
        };
        */

    }

    @Override
    public void onLocationChanged(@NonNull Location location) {

        currentLat = location.getLatitude();
        currentLong = location.getLongitude();

        currentLocation = location;
        geocoder = new Geocoder(MainActivity.this, Locale.US);

        try {
            address = geocoder.getFromLocation(currentLat,currentLong,1);
        } catch (IOException e) {
            e.printStackTrace();
        }
        t.setText("Latitude: "+currentLat+"\n"+"Longitude: "+currentLong+"\n");
        t2.setText(address.get(0).getAddressLine(0));
        t4.setText((String.valueOf(time)));

        prevlat = currentLat;
        prevLong = currentLong;


      location1.add(location);
        if(location1.size()>1){
            Location location2 = location1.get(location1.size()-2);
            Location location3 = location1.get(location1.size()-1);

            double distance=location2.distanceTo(location3);
            totalDistance+=distance;
            t3.setText("Distance Traveled: "+(totalDistance)+" meters");
        }
        else
            t3.setText("Distance Traveled: 0.0");




    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 0) {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                l = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
                l.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1, locationListener);
            }
        }
    }
